package com.example.mycorrectlysitting;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextClock;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends seviceConnectActivity {
    MySittingReceiver mySittingReceiver;
    ImageView posture_image;
    TextView posture_name_textview;
    TextView is_posture_correct_textview;
    String[] posture_name_array;
    String[] is_posture_correct_array;
    ArrayList<Integer> posture_pic;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //각종 뷰 get id
        posture_image = findViewById(R.id.sitting_image);
        posture_name_textview = findViewById(R.id.sitting_name);
        is_posture_correct_textview = findViewById(R.id.is_sitting_correct);

        //리소스 stringarray 가져오기
        Resources res = getResources();
        posture_name_array = res.getStringArray(R.array.sit_names);
        is_posture_correct_array = res.getStringArray(R.array.is_this_correct);

        posture_pic = new ArrayList<>();
        posture_pic.add(R.drawable.posture_1);
        posture_pic.add(R.drawable.posture_2);
        posture_pic.add(R.drawable.posture_3);
        posture_pic.add(R.drawable.posture_4);
        posture_pic.add(R.drawable.posture_5);

        serviceBind(MainActivity.this, true); //서비스 바인드
        mySittingReceiver = new MySittingReceiver(); //브로드캐스트 리시버 객체 생섭
    }

    //서비스 부분 끝
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(isService){
            unbindService(conn); // 서비스 종료
            isService = false;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mySittingReceiver);
    }

    @Override
    protected void onResume() {
        super.onResume();
        //인텐트 필터 정의 및 사용자 정의 브로드 캐스트 리시버 시작
        final IntentFilter theFilter = new IntentFilter();
        theFilter.addAction("SITTING_POSTURE");
        registerReceiver(mySittingReceiver, theFilter);
    }
    public class MySittingReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            int sitting_state = myService.sitting_state;
            Log.e("sitting(activity):", sitting_state+"");

            posture_image.setImageResource(posture_pic.get(sitting_state));
            posture_name_textview.setText(posture_name_array[sitting_state]);
            if(sitting_state>0) {
                is_posture_correct_textview.setTextColor(Color.RED);
                is_posture_correct_textview.setText(is_posture_correct_array[1]);
            }else {
                is_posture_correct_textview.setTextColor(Color.BLACK);
                is_posture_correct_textview.setText(is_posture_correct_array[0]);
            }

        }
    }
}
